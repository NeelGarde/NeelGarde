/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA5 aliases
#define s1_led_TRIS                 TRISAbits.TRISA5
#define s1_led_LAT                  LATAbits.LATA5
#define s1_led_PORT                 PORTAbits.RA5
#define s1_led_WPU                  WPUAbits.WPUA5
#define s1_led_OD                   ODCONAbits.ODCA5
#define s1_led_ANS                  ANSELAbits.ANSELA5
#define s1_led_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define s1_led_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define s1_led_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define s1_led_GetValue()           PORTAbits.RA5
#define s1_led_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define s1_led_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define s1_led_SetPullup()          do { WPUAbits.WPUA5 = 1; } while(0)
#define s1_led_ResetPullup()        do { WPUAbits.WPUA5 = 0; } while(0)
#define s1_led_SetPushPull()        do { ODCONAbits.ODCA5 = 0; } while(0)
#define s1_led_SetOpenDrain()       do { ODCONAbits.ODCA5 = 1; } while(0)
#define s1_led_SetAnalogMode()      do { ANSELAbits.ANSELA5 = 1; } while(0)
#define s1_led_SetDigitalMode()     do { ANSELAbits.ANSELA5 = 0; } while(0)

// get/set RB0 aliases
#define s3_led_TRIS                 TRISBbits.TRISB0
#define s3_led_LAT                  LATBbits.LATB0
#define s3_led_PORT                 PORTBbits.RB0
#define s3_led_WPU                  WPUBbits.WPUB0
#define s3_led_OD                   ODCONBbits.ODCB0
#define s3_led_ANS                  ANSELBbits.ANSELB0
#define s3_led_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define s3_led_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define s3_led_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define s3_led_GetValue()           PORTBbits.RB0
#define s3_led_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define s3_led_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define s3_led_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define s3_led_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define s3_led_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define s3_led_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define s3_led_SetAnalogMode()      do { ANSELBbits.ANSELB0 = 1; } while(0)
#define s3_led_SetDigitalMode()     do { ANSELBbits.ANSELB0 = 0; } while(0)

// get/set RB3 aliases
#define s2_led_TRIS                 TRISBbits.TRISB3
#define s2_led_LAT                  LATBbits.LATB3
#define s2_led_PORT                 PORTBbits.RB3
#define s2_led_WPU                  WPUBbits.WPUB3
#define s2_led_OD                   ODCONBbits.ODCB3
#define s2_led_ANS                  ANSELBbits.ANSELB3
#define s2_led_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define s2_led_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define s2_led_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define s2_led_GetValue()           PORTBbits.RB3
#define s2_led_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define s2_led_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define s2_led_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define s2_led_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define s2_led_SetPushPull()        do { ODCONBbits.ODCB3 = 0; } while(0)
#define s2_led_SetOpenDrain()       do { ODCONBbits.ODCB3 = 1; } while(0)
#define s2_led_SetAnalogMode()      do { ANSELBbits.ANSELB3 = 1; } while(0)
#define s2_led_SetDigitalMode()     do { ANSELBbits.ANSELB3 = 0; } while(0)

// get/set RC2 aliases
#define s3_tx_TRIS                 TRISCbits.TRISC2
#define s3_tx_LAT                  LATCbits.LATC2
#define s3_tx_PORT                 PORTCbits.RC2
#define s3_tx_WPU                  WPUCbits.WPUC2
#define s3_tx_OD                   ODCONCbits.ODCC2
#define s3_tx_ANS                  ANSELCbits.ANSELC2
#define s3_tx_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define s3_tx_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define s3_tx_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define s3_tx_GetValue()           PORTCbits.RC2
#define s3_tx_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define s3_tx_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define s3_tx_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define s3_tx_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define s3_tx_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define s3_tx_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define s3_tx_SetAnalogMode()      do { ANSELCbits.ANSELC2 = 1; } while(0)
#define s3_tx_SetDigitalMode()     do { ANSELCbits.ANSELC2 = 0; } while(0)

// get/set RC3 aliases
#define s3_rx_TRIS                 TRISCbits.TRISC3
#define s3_rx_LAT                  LATCbits.LATC3
#define s3_rx_PORT                 PORTCbits.RC3
#define s3_rx_WPU                  WPUCbits.WPUC3
#define s3_rx_OD                   ODCONCbits.ODCC3
#define s3_rx_ANS                  ANSELCbits.ANSELC3
#define s3_rx_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define s3_rx_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define s3_rx_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define s3_rx_GetValue()           PORTCbits.RC3
#define s3_rx_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define s3_rx_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define s3_rx_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define s3_rx_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define s3_rx_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define s3_rx_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define s3_rx_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define s3_rx_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RC5 aliases
#define s2_tx_TRIS                 TRISCbits.TRISC5
#define s2_tx_LAT                  LATCbits.LATC5
#define s2_tx_PORT                 PORTCbits.RC5
#define s2_tx_WPU                  WPUCbits.WPUC5
#define s2_tx_OD                   ODCONCbits.ODCC5
#define s2_tx_ANS                  ANSELCbits.ANSELC5
#define s2_tx_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define s2_tx_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define s2_tx_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define s2_tx_GetValue()           PORTCbits.RC5
#define s2_tx_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define s2_tx_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define s2_tx_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define s2_tx_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define s2_tx_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define s2_tx_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define s2_tx_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define s2_tx_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

// get/set RC6 aliases
#define s2_rx_TRIS                 TRISCbits.TRISC6
#define s2_rx_LAT                  LATCbits.LATC6
#define s2_rx_PORT                 PORTCbits.RC6
#define s2_rx_WPU                  WPUCbits.WPUC6
#define s2_rx_OD                   ODCONCbits.ODCC6
#define s2_rx_ANS                  ANSELCbits.ANSELC6
#define s2_rx_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define s2_rx_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define s2_rx_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define s2_rx_GetValue()           PORTCbits.RC6
#define s2_rx_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define s2_rx_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define s2_rx_SetPullup()          do { WPUCbits.WPUC6 = 1; } while(0)
#define s2_rx_ResetPullup()        do { WPUCbits.WPUC6 = 0; } while(0)
#define s2_rx_SetPushPull()        do { ODCONCbits.ODCC6 = 0; } while(0)
#define s2_rx_SetOpenDrain()       do { ODCONCbits.ODCC6 = 1; } while(0)
#define s2_rx_SetAnalogMode()      do { ANSELCbits.ANSELC6 = 1; } while(0)
#define s2_rx_SetDigitalMode()     do { ANSELCbits.ANSELC6 = 0; } while(0)

// get/set RC7 aliases
#define btn_2_TRIS                 TRISCbits.TRISC7
#define btn_2_LAT                  LATCbits.LATC7
#define btn_2_PORT                 PORTCbits.RC7
#define btn_2_WPU                  WPUCbits.WPUC7
#define btn_2_OD                   ODCONCbits.ODCC7
#define btn_2_ANS                  ANSELCbits.ANSELC7
#define btn_2_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define btn_2_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define btn_2_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define btn_2_GetValue()           PORTCbits.RC7
#define btn_2_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define btn_2_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define btn_2_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define btn_2_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define btn_2_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define btn_2_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define btn_2_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define btn_2_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

// get/set RD0 aliases
#define btn_1_TRIS                 TRISDbits.TRISD0
#define btn_1_LAT                  LATDbits.LATD0
#define btn_1_PORT                 PORTDbits.RD0
#define btn_1_WPU                  WPUDbits.WPUD0
#define btn_1_OD                   ODCONDbits.ODCD0
#define btn_1_ANS                  ANSELDbits.ANSELD0
#define btn_1_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define btn_1_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define btn_1_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define btn_1_GetValue()           PORTDbits.RD0
#define btn_1_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define btn_1_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define btn_1_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define btn_1_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define btn_1_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define btn_1_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define btn_1_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define btn_1_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set RD1 aliases
#define btn_4_TRIS                 TRISDbits.TRISD1
#define btn_4_LAT                  LATDbits.LATD1
#define btn_4_PORT                 PORTDbits.RD1
#define btn_4_WPU                  WPUDbits.WPUD1
#define btn_4_OD                   ODCONDbits.ODCD1
#define btn_4_ANS                  ANSELDbits.ANSELD1
#define btn_4_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define btn_4_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define btn_4_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define btn_4_GetValue()           PORTDbits.RD1
#define btn_4_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define btn_4_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define btn_4_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define btn_4_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define btn_4_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define btn_4_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define btn_4_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define btn_4_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RD2 aliases
#define btn_extra_TRIS                 TRISDbits.TRISD2
#define btn_extra_LAT                  LATDbits.LATD2
#define btn_extra_PORT                 PORTDbits.RD2
#define btn_extra_WPU                  WPUDbits.WPUD2
#define btn_extra_OD                   ODCONDbits.ODCD2
#define btn_extra_ANS                  ANSELDbits.ANSELD2
#define btn_extra_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define btn_extra_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define btn_extra_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define btn_extra_GetValue()           PORTDbits.RD2
#define btn_extra_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define btn_extra_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define btn_extra_SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define btn_extra_ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define btn_extra_SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define btn_extra_SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define btn_extra_SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define btn_extra_SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

// get/set RE2 aliases
#define btn_3_TRIS                 TRISEbits.TRISE2
#define btn_3_LAT                  LATEbits.LATE2
#define btn_3_PORT                 PORTEbits.RE2
#define btn_3_WPU                  WPUEbits.WPUE2
#define btn_3_OD                   ODCONEbits.ODCE2
#define btn_3_ANS                  ANSELEbits.ANSELE2
#define btn_3_SetHigh()            do { LATEbits.LATE2 = 1; } while(0)
#define btn_3_SetLow()             do { LATEbits.LATE2 = 0; } while(0)
#define btn_3_Toggle()             do { LATEbits.LATE2 = ~LATEbits.LATE2; } while(0)
#define btn_3_GetValue()           PORTEbits.RE2
#define btn_3_SetDigitalInput()    do { TRISEbits.TRISE2 = 1; } while(0)
#define btn_3_SetDigitalOutput()   do { TRISEbits.TRISE2 = 0; } while(0)
#define btn_3_SetPullup()          do { WPUEbits.WPUE2 = 1; } while(0)
#define btn_3_ResetPullup()        do { WPUEbits.WPUE2 = 0; } while(0)
#define btn_3_SetPushPull()        do { ODCONEbits.ODCE2 = 0; } while(0)
#define btn_3_SetOpenDrain()       do { ODCONEbits.ODCE2 = 1; } while(0)
#define btn_3_SetAnalogMode()      do { ANSELEbits.ANSELE2 = 1; } while(0)
#define btn_3_SetDigitalMode()     do { ANSELEbits.ANSELE2 = 0; } while(0)

// get/set RF0 aliases
#define s1_tx_TRIS                 TRISFbits.TRISF0
#define s1_tx_LAT                  LATFbits.LATF0
#define s1_tx_PORT                 PORTFbits.RF0
#define s1_tx_WPU                  WPUFbits.WPUF0
#define s1_tx_OD                   ODCONFbits.ODCF0
#define s1_tx_ANS                  ANSELFbits.ANSELF0
#define s1_tx_SetHigh()            do { LATFbits.LATF0 = 1; } while(0)
#define s1_tx_SetLow()             do { LATFbits.LATF0 = 0; } while(0)
#define s1_tx_Toggle()             do { LATFbits.LATF0 = ~LATFbits.LATF0; } while(0)
#define s1_tx_GetValue()           PORTFbits.RF0
#define s1_tx_SetDigitalInput()    do { TRISFbits.TRISF0 = 1; } while(0)
#define s1_tx_SetDigitalOutput()   do { TRISFbits.TRISF0 = 0; } while(0)
#define s1_tx_SetPullup()          do { WPUFbits.WPUF0 = 1; } while(0)
#define s1_tx_ResetPullup()        do { WPUFbits.WPUF0 = 0; } while(0)
#define s1_tx_SetPushPull()        do { ODCONFbits.ODCF0 = 0; } while(0)
#define s1_tx_SetOpenDrain()       do { ODCONFbits.ODCF0 = 1; } while(0)
#define s1_tx_SetAnalogMode()      do { ANSELFbits.ANSELF0 = 1; } while(0)
#define s1_tx_SetDigitalMode()     do { ANSELFbits.ANSELF0 = 0; } while(0)

// get/set RF1 aliases
#define s1_rx_TRIS                 TRISFbits.TRISF1
#define s1_rx_LAT                  LATFbits.LATF1
#define s1_rx_PORT                 PORTFbits.RF1
#define s1_rx_WPU                  WPUFbits.WPUF1
#define s1_rx_OD                   ODCONFbits.ODCF1
#define s1_rx_ANS                  ANSELFbits.ANSELF1
#define s1_rx_SetHigh()            do { LATFbits.LATF1 = 1; } while(0)
#define s1_rx_SetLow()             do { LATFbits.LATF1 = 0; } while(0)
#define s1_rx_Toggle()             do { LATFbits.LATF1 = ~LATFbits.LATF1; } while(0)
#define s1_rx_GetValue()           PORTFbits.RF1
#define s1_rx_SetDigitalInput()    do { TRISFbits.TRISF1 = 1; } while(0)
#define s1_rx_SetDigitalOutput()   do { TRISFbits.TRISF1 = 0; } while(0)
#define s1_rx_SetPullup()          do { WPUFbits.WPUF1 = 1; } while(0)
#define s1_rx_ResetPullup()        do { WPUFbits.WPUF1 = 0; } while(0)
#define s1_rx_SetPushPull()        do { ODCONFbits.ODCF1 = 0; } while(0)
#define s1_rx_SetOpenDrain()       do { ODCONFbits.ODCF1 = 1; } while(0)
#define s1_rx_SetAnalogMode()      do { ANSELFbits.ANSELF1 = 1; } while(0)
#define s1_rx_SetDigitalMode()     do { ANSELFbits.ANSELF1 = 0; } while(0)

// get/set RF7 aliases
#define spkr_TRIS                 TRISFbits.TRISF7
#define spkr_LAT                  LATFbits.LATF7
#define spkr_PORT                 PORTFbits.RF7
#define spkr_WPU                  WPUFbits.WPUF7
#define spkr_OD                   ODCONFbits.ODCF7
#define spkr_ANS                  ANSELFbits.ANSELF7
#define spkr_SetHigh()            do { LATFbits.LATF7 = 1; } while(0)
#define spkr_SetLow()             do { LATFbits.LATF7 = 0; } while(0)
#define spkr_Toggle()             do { LATFbits.LATF7 = ~LATFbits.LATF7; } while(0)
#define spkr_GetValue()           PORTFbits.RF7
#define spkr_SetDigitalInput()    do { TRISFbits.TRISF7 = 1; } while(0)
#define spkr_SetDigitalOutput()   do { TRISFbits.TRISF7 = 0; } while(0)
#define spkr_SetPullup()          do { WPUFbits.WPUF7 = 1; } while(0)
#define spkr_ResetPullup()        do { WPUFbits.WPUF7 = 0; } while(0)
#define spkr_SetPushPull()        do { ODCONFbits.ODCF7 = 0; } while(0)
#define spkr_SetOpenDrain()       do { ODCONFbits.ODCF7 = 1; } while(0)
#define spkr_SetAnalogMode()      do { ANSELFbits.ANSELF7 = 1; } while(0)
#define spkr_SetDigitalMode()     do { ANSELFbits.ANSELF7 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/