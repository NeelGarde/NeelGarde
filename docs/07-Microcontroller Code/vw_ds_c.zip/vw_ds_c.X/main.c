#include "mcc_generated_files/system/system.h"

/*
    Main application
*/
char sys = 0;
char tst = 0;

int spkr_safe(void)
{
    spkr_SetHigh();
    __delay_ms(3);
    spkr_SetLow();
    __delay_ms(20);
}

int spkr_danger(void)
{
    for (int i = 1; i <= 3; i++){
        spkr_SetHigh();
        __delay_ms(1);
        spkr_SetLow();
        __delay_ms(1);
    }
    __delay_ms(3);
}

int main(void)
{
    SYSTEM_Initialize();

    while(1){
        // Buttons/subsystem select
        if (btn_1_GetValue() == 0){
            s1_led_Toggle();
            if ( sys == 1){
                tst = !tst;
            } else {
                sys = 1;
                tst = 1;
                s1_led_SetHigh();
                s2_led_SetLow();
                s3_led_SetLow();
            }
            __delay_ms(10);
        }
        if (btn_2_GetValue() == 0){
            s2_led_Toggle();
            if ( sys == 2){
                tst = !tst;
            } else {
                sys = 2;
                tst = 1;
                s2_led_SetHigh();
                s1_led_SetLow();
                s3_led_SetLow();
            }
            __delay_ms(10);
        } 
        if (btn_3_GetValue() == 0){
            s3_led_Toggle();
            if ( sys == 3){
                tst = !tst;
            } else {
                sys = 3;
                tst = 1;
                s3_led_SetHigh();
                s2_led_SetLow();
                s1_led_SetLow();
            }
            __delay_ms(10);
        }
        
        // Speaker/status readout
        switch (sys){
                case 1:
                    s1_tx_SetHigh();
                    s2_tx_SetLow();
                    s3_tx_SetLow();
                    
                    if (s1_rx_GetValue() == 0){
                        spkr_safe();
                    } else {
                        spkr_danger();
                    }
                    break;
                    
                case 2:
                    s2_tx_SetHigh();
                    s1_tx_SetLow();
                    s3_tx_SetLow();
                    
                    if (s2_rx_GetValue() == 0){
                        spkr_safe();
                    } else {
                        spkr_danger();
                    }
                    break;
                    
                case 3:
                    s3_tx_SetHigh();
                    s2_tx_SetLow();
                    s1_tx_SetLow();
                    
                    if (s3_rx_GetValue() == 0){
                        spkr_safe();
                    } else {
                        spkr_danger();
                    }
                    break;
        }
    }    
}